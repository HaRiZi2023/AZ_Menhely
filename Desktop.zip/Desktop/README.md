# History 
Version | Name    | Date     | Changes
     0.1| Cser    |2024-02-20| Desktop mappa és readme elkészítése